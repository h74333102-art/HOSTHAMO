# بناء HAMOHOST

المشروع يستخدم Chaquopy 17.0 لدمج Python داخل تطبيق Android. الإصدار الحالي من Chaquopy موثق بأنه يدعم Android Gradle Plugin من 7.3.x إلى 9.2.x، ويدعم Python 3.13. يجب أن تكون Python 3.13 مثبتة على جهاز البناء عند الحاجة إلى ميزات تتطلب buildPython.

1. افتح المشروع في Android Studio.
2. تأكد من توفر JDK المناسب وPython 3.13.
3. اعمل Gradle Sync.
4. Build > Build APK(s).

النسخة تشغل `main.py` من المشروع المرفوع داخل Python runtime المدمج. الحزم الخارجية المضمّنة حاليًا: Flask و Requests. لا يمكن تثبيت أي `requirements.txt` عشوائيًا على الهاتف وقت التشغيل بهذه الطريقة؛ الحزم يجب إضافتها في إعدادات Chaquopy ثم إعادة بناء APK.
