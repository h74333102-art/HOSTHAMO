
import os, sys, io, runpy, traceback, threading, contextlib

_stop = False

def run_script(script_path, log_path):
    global _stop
    _stop = False
    project = os.path.dirname(script_path)
    if project not in sys.path:
        sys.path.insert(0, project)

    class Tee(io.TextIOBase):
        def __init__(self, f):
            self.f = f
        def write(self, s):
            try:
                self.f.write(s)
                self.f.flush()
            except Exception:
                pass
            return len(s)
        def flush(self):
            try: self.f.flush()
            except Exception: pass

    with open(log_path, "a", encoding="utf-8", buffering=1) as f:
        f.write("\n=== HAMOHOST: START ===\n")
        f.write("Python: " + sys.version.split()[0] + "\n")
        f.write("Project: " + project + "\n\n")
        tee = Tee(f)
        try:
            with contextlib.redirect_stdout(tee), contextlib.redirect_stderr(tee):
                runpy.run_path(script_path, run_name="__main__")
        except SystemExit as e:
            f.write("\nSystemExit: %s\n" % e)
        except Exception:
            traceback.print_exc(file=tee)
        finally:
            f.write("\n=== HAMOHOST: PROCESS ENDED ===\n")

def clear_log(log_path):
    with open(log_path, "w", encoding="utf-8") as f:
        f.write("HAMOHOST Console\n")
