
package com.hamohost;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.zip.*;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

public class MainActivity extends Activity {
    LinearLayout content, root;
    TextView status, console;
    File projectDir, logFile;
    Thread runnerThread;
    Handler handler = new Handler();

    int purple = Color.rgb(108,53,201);
    int dark = Color.rgb(40,35,45);

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(dark);
        return t;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(14); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackgroundResource(com.hamohost.R.drawable.bg_button);
        b.setPadding(dp(14),0,dp(14),0);
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
        startLogRefresh();
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22),dp(18),dp(22),dp(18));
        header.setBackgroundResource(R.drawable.bg_gradient);

        TextView title = tv("HAMOHOST", 28);
        title.setTextColor(Color.WHITE); title.setTypeface(null, Typeface.BOLD);
        header.addView(title);
        TextView dev = tv("Telegram Bot & Python Hosting  •  Developed by Hamo", 13);
        dev.setTextColor(Color.WHITE); header.addView(dev);
        root.addView(header);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16),dp(16),dp(16),dp(8));
        root.addView(content, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(8),dp(6),dp(8),dp(8));
        nav.setBackgroundResource(R.drawable.bg_bottom);
        String[] labels={"⌂  Home","▦  Resources","▣  Console"};
        for(String s:labels){
            Button n=button(s);
            n.setTextColor(dark); n.setBackgroundColor(Color.TRANSPARENT);
            nav.addView(n,new LinearLayout.LayoutParams(0,dp(52),1));
            if(s.contains("Home")) n.setOnClickListener(v->home());
            if(s.contains("Resources")) n.setOnClickListener(v->resources());
            if(s.contains("Console")) n.setOnClickListener(v->consolePage());
        }
        root.addView(nav);
        setContentView(root);
        home();
    }

    TextView heading(String s){
        TextView t=tv(s,22); t.setTypeface(null,Typeface.BOLD);
        t.setPadding(0,0,0,dp(12)); return t;
    }

    void home(){
        content.removeAllViews();
        content.addView(heading("Your Python Hosting"));
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(18),dp(18),dp(18));
        card.setBackgroundResource(R.drawable.bg_card);
        TextView welcome=tv("استضف مشروع Python من هاتفك بسهولة",19);
        welcome.setTypeface(null,Typeface.BOLD); card.addView(welcome);
        status=tv("\n●  الحالة: "+(projectDir==null?"لا يوجد مشروع":"المشروع جاهز"),15);
        card.addView(status);

        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(190));
        p.setMargins(0,0,0,dp(14)); content.addView(card,p);

        Button upload=button("＋  Upload Python Project (ZIP)");
        upload.setOnClickListener(v->pickZip()); content.addView(upload);

        Button run=button("▶  Start Project");
        run.setOnClickListener(v->runProject()); content.addView(run);

        Button stop=button("■  Stop");
        stop.setOnClickListener(v->stopProject()); content.addView(stop);

        TextView hint=tv("\nيدعم main.py. تم تضمين Flask و Requests داخل نسخة التطبيق.",14);
        hint.setTextColor(Color.GRAY); content.addView(hint);
    }

    void resources(){
        content.removeAllViews();
        content.addView(heading("Resources"));
        TextView t=tv("• Python 3.13 Runtime\n• Flask\n• Requests\n• Project storage\n• ZIP upload\n• Local console",17);
        content.addView(t);
    }

    void consolePage(){
        content.removeAllViews();
        content.addView(heading("Console"));
        console=tv("HAMOHOST Console\n",13);
        console.setTextColor(Color.WHITE); console.setBackgroundColor(Color.rgb(25,23,29));
        console.setPadding(dp(12),dp(12),dp(12),dp(12));
        content.addView(console,new LinearLayout.LayoutParams(-1,0,1));
        refreshConsole();
    }

    void pickZip(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/zip"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,55);
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req!=55 || res!=RESULT_OK || data==null) return;
        try{
            projectDir=new File(getFilesDir(),"hamohost_project");
            delete(projectDir); projectDir.mkdirs();
            unzip(data.getData(),projectDir);
            logFile=new File(getFilesDir(),"hamohost.log");
            PyObject r=Python.getInstance().getModule("runner");
            r.callAttr("clear_log",logFile.getAbsolutePath());
            Toast.makeText(this,"تم رفع المشروع",Toast.LENGTH_SHORT).show();
            home();
        }catch(Exception e){
            Toast.makeText(this,"فشل الرفع: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    void unzip(Uri uri,File out)throws Exception{
        ZipInputStream z=new ZipInputStream(getContentResolver().openInputStream(uri));
        ZipEntry e; byte[] buf=new byte[8192];
        while((e=z.getNextEntry())!=null){
            String name=e.getName();
            if(name.contains("..") || name.startsWith("/")) continue;
            File f=new File(out,name);
            if(e.isDirectory()){f.mkdirs();continue;}
            f.getParentFile().mkdirs();
            FileOutputStream o=new FileOutputStream(f);
            int n; while((n=z.read(buf))>0)o.write(buf,0,n); o.close();
        }
        z.close();
    }

    void runProject(){
        if(projectDir==null){Toast.makeText(this,"ارفع مشروع ZIP أولًا",Toast.LENGTH_SHORT).show();return;}
        File main=new File(projectDir,"main.py");
        if(!main.exists()){Toast.makeText(this,"ضع main.py في جذر المشروع",Toast.LENGTH_LONG).show();return;}
        if(runnerThread!=null && runnerThread.isAlive()){Toast.makeText(this,"المشروع يعمل بالفعل",Toast.LENGTH_SHORT).show();return;}
        if(logFile==null) logFile=new File(getFilesDir(),"hamohost.log");
        final String script=main.getAbsolutePath(), log=logFile.getAbsolutePath();
        runnerThread=new Thread(()->{
            try{
                PyObject r=Python.getInstance().getModule("runner");
                r.callAttr("run_script",script,log);
            }catch(Exception e){
                try{ FileWriter w=new FileWriter(log,true); w.write("\nJAVA ERROR: "+e+"\n"); w.close(); }catch(Exception ignored){}
            }
        });
        runnerThread.start();
        status.setText("\n●  الحالة: يعمل");
        Toast.makeText(this,"تم تشغيل المشروع",Toast.LENGTH_SHORT).show();
    }

    void stopProject(){
        if(runnerThread!=null && runnerThread.isAlive()){
            runnerThread.interrupt();
            Toast.makeText(this,"تم طلب إيقاف المشروع",Toast.LENGTH_SHORT).show();
        }
        if(status!=null) status.setText("\n●  الحالة: متوقف / تم طلب الإيقاف");
    }

    void startLogRefresh(){
        handler.postDelayed(new Runnable(){public void run(){
            refreshConsole(); handler.postDelayed(this,1000);
        }},1000);
    }

    void refreshConsole(){
        if(console==null || logFile==null || !logFile.exists()) return;
        try{
            BufferedReader r=new BufferedReader(new FileReader(logFile));
            StringBuilder s=new StringBuilder(); String line;
            while((line=r.readLine())!=null){s.append(line).append("\n");}
            r.close(); console.setText(s.toString());
        }catch(Exception ignored){}
    }

    void delete(File f){
        if(!f.exists())return;
        if(f.isDirectory() && f.listFiles()!=null) for(File x:f.listFiles()) delete(x);
        f.delete();
    }
}
